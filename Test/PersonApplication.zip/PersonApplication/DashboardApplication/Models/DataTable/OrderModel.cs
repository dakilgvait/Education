﻿namespace DashboardApplication.Models.DataTable
{
    public class OrderModel
    {
        public int column { get; set; }
        public string dir { get; set; }
    }
}