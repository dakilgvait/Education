﻿namespace DashboardApplication.Models.DataTable
{
    public class SearchModel
    {
        public string value { get; set; }
        public string regex { get; set; }
    }
}