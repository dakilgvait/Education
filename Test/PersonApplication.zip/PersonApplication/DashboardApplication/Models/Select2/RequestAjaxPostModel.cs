﻿namespace DashboardApplication.Models.Select2
{
    public class RequestAjaxPostModel
    {
        public string _type { get; set; }
        public string name { get; set; }
    }
}