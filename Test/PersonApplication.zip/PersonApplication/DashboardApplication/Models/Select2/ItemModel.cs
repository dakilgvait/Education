﻿namespace DashboardApplication.Models.Select2
{
    public class ItemModel
    {
        public int Id { get; set; }
        public string Text { get; set; }
    }
}